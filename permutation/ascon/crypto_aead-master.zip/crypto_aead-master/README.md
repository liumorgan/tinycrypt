### This is the reference source code package of ASCON.
ASCON is a new family of authenticated encryption algorithms, submitted to the [CAESAR competition](http://competitions.cr.yp.to/caesar.html) for authenticated encryption. The specification and more details about ASCON can be found on its [website](http://ascon.iaik.tugraz.at).
